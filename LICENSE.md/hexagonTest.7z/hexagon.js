var SIZE = 30;// Радиус описанной окружности правильного шестиугольника
var ROWS = 15;
var COLS = 15;



// Основные размеры хексагона, отспупы
var width = SIZE * 2,
    horizPadding = width * 3/4,
    height = Math.sqrt(3)/2 * width,
    vertPadding = height/2;




// Сам процесс
allCentralPoints = getAllCentralPoints();
for (var i = 0; i < allCentralPoints.length; i++) {
    svg(getPointsFigure(
        allCentralPoints[i][0],
        allCentralPoints[i][1]
    ));
}



//  РАссчет центров хексагонов
function getAllCentralPoints() {
    var figurePoints = [];
    for (var row = 1; row <= ROWS; row++) {
        for (var col = 1; col <= COLS; col++) {

            x = 1/2*width;
            y = 1/2*height;

            if (row & 1) {// если нечетная строка
                figurePoints.push([
                    x + (horizPadding*2*(col-1)),
                    y + (vertPadding*(row-1))
                ]);
            }
            else{// если четка то добавим отступ
                figurePoints.push([
                    x + (horizPadding*2*(col-1)+horizPadding),
                    y + (vertPadding*(row-1))
                ]);
            }

        }
    }

    return figurePoints;
}


//  Рассчет центров хексагонов
function getPointsFigure(x, y) {
    var arrPoints = [];

    for (var i = 1; i <= 6; i++) {
        var deg = 60 * i   + 30;
        var rad = Math.PI / 180 * deg;

        arrPoints.push([
            (x + SIZE * Math.sin(rad)).toFixed(8),
            (y + SIZE * Math.cos(rad)).toFixed(8)
        ]);
    }
    return arrPoints;
}


//  Рендер хексагона
function svg(arrPoints) {
    var mysvg =  document.getElementById("svg");
    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
    newElement.setAttribute('d', 'M'+arrPoints.toString()+'z');
    mysvg.appendChild(newElement);

}










